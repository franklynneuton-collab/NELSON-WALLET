const { randomUUID: uuid } = require('crypto');
const { db } = require('../config/db');

/** Append-only audit trail for financial/admin-sensitive actions. */
function log(actorId, action, { targetType, targetId, metadata } = {}) {
  db.prepare(`
    INSERT INTO audit_logs (id, actor_id, action, target_type, target_id, metadata)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(uuid(), actorId || null, action, targetType || null, targetId || null,
    metadata ? JSON.stringify(metadata) : null);
}

module.exports = { log };
