const express = require('express');
const { db } = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/requireAuth');
const { balanceOf, getOrCreateSystemAccount } = require('../services/ledger');
const audit = require('../services/audit');

const router = express.Router();
router.use(requireAuth, requireAdmin);

router.get('/users', (req, res) => {
  const { q } = req.query;
  const rows = q
    ? db.prepare(`SELECT id, email, name, role, kyc_status, suspended, created_at FROM users
        WHERE email LIKE ? OR name LIKE ? ORDER BY created_at DESC LIMIT 200`).all(`%${q}%`, `%${q}%`)
    : db.prepare(`SELECT id, email, name, role, kyc_status, suspended, created_at FROM users
        ORDER BY created_at DESC LIMIT 200`).all();
  res.json({ users: rows });
});

router.patch('/users/:id', (req, res) => {
  const { suspended, role } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'not_found' });

  if (typeof suspended === 'boolean') {
    db.prepare(`UPDATE users SET suspended = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(suspended ? 1 : 0, req.params.id);
    audit.log(req.user.sub, suspended ? 'user_suspended' : 'user_unsuspended', { targetType: 'user', targetId: req.params.id });
  }
  if (role && ['user', 'seller', 'admin'].includes(role)) {
    db.prepare(`UPDATE users SET role = ?, updated_at = datetime('now') WHERE id = ?`).run(role, req.params.id);
    audit.log(req.user.sub, 'user_role_changed', { targetType: 'user', targetId: req.params.id, metadata: { role } });
  }
  res.json({ user: db.prepare('SELECT id, email, name, role, kyc_status, suspended FROM users WHERE id = ?').get(req.params.id) });
});

router.get('/kyc/pending', (req, res) => {
  const rows = db.prepare(`SELECT id, email, name, kyc_status, updated_at FROM users
    WHERE kyc_status IN ('pending', 'manual_review') ORDER BY updated_at ASC`).all();
  res.json({ users: rows });
});

router.patch('/kyc/:userId', (req, res) => {
  const { decision } = req.body; // 'verified' | 'rejected'
  if (!['verified', 'rejected'].includes(decision)) return res.status(400).json({ error: 'invalid_decision' });
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.userId);
  if (!user) return res.status(404).json({ error: 'not_found' });

  db.prepare(`UPDATE users SET kyc_status = ?, updated_at = datetime('now') WHERE id = ?`).run(decision, req.params.userId);
  audit.log(req.user.sub, 'kyc_decision', { targetType: 'user', targetId: req.params.userId, metadata: { decision } });
  res.json({ kycStatus: decision });
});

router.get('/orders', (req, res) => {
  const { status } = req.query;
  const rows = status
    ? db.prepare(`SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC LIMIT 200`).all(status)
    : db.prepare(`SELECT * FROM orders ORDER BY created_at DESC LIMIT 200`).all();
  res.json({ orders: rows });
});

router.get('/products', (req, res) => {
  const rows = db.prepare(`SELECT * FROM products ORDER BY created_at DESC LIMIT 200`).all();
  res.json({ products: rows });
});

// Ledger/revenue summary — platform commission and escrow-in-flight, per currency.
router.get('/ledger/summary', (req, res) => {
  const currencies = db.prepare(`SELECT DISTINCT currency FROM accounts`).all().map((r) => r.currency);
  const summary = currencies.map((currency) => {
    const escrow = getOrCreateSystemAccount('escrow', currency);
    const fees = getOrCreateSystemAccount('fee_revenue', currency);
    return {
      currency,
      escrowHeldCents: balanceOf(escrow.id),
      platformRevenueCents: balanceOf(fees.id),
    };
  });
  const orderStats = db.prepare(`
    SELECT status, COUNT(*) AS count, COALESCE(SUM(total_cents), 0) AS total_cents
    FROM orders GROUP BY status
  `).all();
  res.json({ byCurrency: summary, ordersByStatus: orderStats });
});

router.get('/audit-logs', (req, res) => {
  const rows = db.prepare(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200`).all();
  res.json({ logs: rows });
});

module.exports = router;
