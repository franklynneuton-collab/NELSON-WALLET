const express = require('express');
const { randomUUID: uuid } = require('crypto');
const { db } = require('../config/db');
const { requireAuth, requireKyc } = require('../middleware/requireAuth');
const { orderSchema, reviewSchema } = require('../utils/schemas');
const {
  getOrCreateWalletAccount, getOrCreateSystemAccount, postTransfer, LedgerError,
} = require('../services/ledger');
const notifications = require('../services/notifications');
const audit = require('../services/audit');

const router = express.Router();

// Platform commission, in basis points (1000 = 10%). Configurable via env so
// it doesn't require a code change/redeploy to adjust; snapshotted onto each
// order at checkout time so later changes never retroactively affect open orders.
const PLATFORM_COMMISSION_BPS = Number.isInteger(Number(process.env.PLATFORM_COMMISSION_BPS))
  ? Number(process.env.PLATFORM_COMMISSION_BPS)
  : 1000;

function loadOrderWithItems(orderId) {
  const order = db.prepare(`SELECT * FROM orders WHERE id = ?`).get(orderId);
  if (!order) return null;
  order.items = db.prepare(`SELECT * FROM order_items WHERE order_id = ?`).all(orderId);
  return order;
}

router.get('/', requireAuth, (req, res) => {
  const orders = db.prepare(`SELECT * FROM orders WHERE buyer_id = ? ORDER BY created_at DESC`).all(req.user.sub);
  const withItems = orders.map((o) => ({
    ...o,
    items: db.prepare(`SELECT * FROM order_items WHERE order_id = ?`).all(o.id),
  }));
  res.json({ orders: withItems });
});

// Orders a user is selling in (not just buying) — needed for the seller dashboard.
router.get('/selling', requireAuth, (req, res) => {
  const items = db.prepare(`
    SELECT oi.*, o.status, o.escrow_status, o.created_at AS order_created_at
    FROM order_items oi JOIN orders o ON o.id = oi.order_id
    WHERE oi.seller_id = ? ORDER BY o.created_at DESC
  `).all(req.user.sub);
  res.json({ items });
});

router.get('/:id', requireAuth, (req, res) => {
  const order = loadOrderWithItems(req.params.id);
  if (!order) return res.status(404).json({ error: 'not_found' });
  const isBuyer = order.buyer_id === req.user.sub;
  const isSeller = order.items.some((i) => i.seller_id === req.user.sub);
  if (!isBuyer && !isSeller && req.user.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
  res.json({ order });
});

// Checkout: validates stock/price/currency server-side, charges the buyer's
// wallet, and moves the funds into escrow — NOT to the seller. Funds only
// reach the seller when the buyer confirms delivery (see /:id/confirm).
router.post('/', requireAuth, requireKyc, async (req, res, next) => {
  try {
    const body = orderSchema.parse(req.body);

    const runCheckout = db.transaction(() => {
      const lineItems = body.items.map(({ productId, qty }) => {
        const product = db.prepare('SELECT * FROM products WHERE id = ? AND status = ?').get(productId, 'live');
        if (!product) throw new LedgerError(`product ${productId} not available`, 'PRODUCT_UNAVAILABLE');
        if (product.stock < qty) throw new LedgerError(`insufficient stock for ${product.name}`, 'INSUFFICIENT_STOCK');
        return { product, qty };
      });

      const currency = lineItems[0].product.currency;
      if (!lineItems.every((li) => li.product.currency === currency)) {
        throw new LedgerError('all items in one order must share a currency', 'MIXED_CURRENCY');
      }

      // Server recomputes the total from current DB prices — the client's
      // number, if any, is never trusted.
      const totalCents = lineItems.reduce((sum, li) => sum + li.product.price_cents * li.qty, 0);
      const buyerAccount = getOrCreateWalletAccount(req.user.sub, currency);
      const escrowAccount = getOrCreateSystemAccount('escrow', currency);

      const orderId = uuid();
      const tx = postTransfer({
        fromAccountId: buyerAccount.id,
        toAccountId: escrowAccount.id,
        amountCents: totalCents,
        currency,
        type: 'order_payment',
        memo: `Order ${orderId} — held in escrow`,
        idempotencyKey: body.idempotencyKey,
      });

      for (const li of lineItems) {
        db.prepare(`UPDATE products SET stock = stock - ? WHERE id = ?`).run(li.qty, li.product.id);
      }

      db.prepare(`
        INSERT INTO orders (id, buyer_id, status, escrow_status, commission_bps, total_cents, currency, ledger_transaction_id)
        VALUES (?, ?, 'processing', 'held', ?, ?, ?, ?)
      `).run(orderId, req.user.sub, PLATFORM_COMMISSION_BPS, totalCents, currency, tx.id);

      for (const li of lineItems) {
        db.prepare(`
          INSERT INTO order_items (id, order_id, product_id, seller_id, name, unit_price_cents, qty)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(uuid(), orderId, li.product.id, li.product.seller_id, li.product.name, li.product.price_cents, li.qty);
      }

      return { orderId, totalCents, currency, lineItems };
    });

    const result = runCheckout();

    await notifications.notify(req.user.sub, {
      type: 'order', title: 'Order Placed!',
      body: `Order ${result.orderId} confirmed — ${(result.totalCents / 100).toFixed(2)} ${result.currency} held in escrow.`,
    });
    for (const li of result.lineItems) {
      await notifications.notify(li.product.seller_id, {
        type: 'sold', title: 'Product Sold!',
        body: `${li.product.name} x${li.qty} just sold. Funds release once the buyer confirms delivery.`,
      });
    }

    res.status(201).json({ orderId: result.orderId, totalCents: result.totalCents, currency: result.currency });
  } catch (err) { next(err); }
});

// Seller marks their line items shipped. Any seller with items on the order
// may call this; it does not touch escrow.
router.post('/:id/ship', requireAuth, async (req, res, next) => {
  try {
    const order = loadOrderWithItems(req.params.id);
    if (!order) return res.status(404).json({ error: 'not_found' });
    if (!order.items.some((i) => i.seller_id === req.user.sub)) return res.status(403).json({ error: 'forbidden' });
    if (order.status !== 'processing') return res.status(409).json({ error: 'invalid_state', status: order.status });

    db.prepare(`UPDATE orders SET status = 'shipped', updated_at = datetime('now') WHERE id = ?`).run(order.id);
    await notifications.notify(order.buyer_id, {
      type: 'shipping', title: 'Order Shipped', body: `Order ${order.id} is on its way.`,
    });
    res.json({ order: { ...order, status: 'shipped' } });
  } catch (err) { next(err); }
});

// Buyer confirms delivery — the ONLY action that releases escrow. Splits
// each seller's share into their net payout (commission deducted) and the
// platform's fee_revenue account. Idempotent per order via each transfer's
// own idempotency key, so a retried request can't double-release.
router.post('/:id/confirm', requireAuth, async (req, res, next) => {
  try {
    const order = loadOrderWithItems(req.params.id);
    if (!order) return res.status(404).json({ error: 'not_found' });
    if (order.buyer_id !== req.user.sub) return res.status(403).json({ error: 'forbidden' });
    if (order.status !== 'shipped') return res.status(409).json({ error: 'invalid_state', status: order.status });
    if (order.escrow_status !== 'held') return res.status(409).json({ error: 'escrow_already_settled' });

    const release = db.transaction(() => {
      const escrowAccount = getOrCreateSystemAccount('escrow', order.currency);
      const feeAccount = getOrCreateSystemAccount('fee_revenue', order.currency);

      // Group items by seller so each seller gets one payout transfer per order.
      const bySeller = new Map();
      for (const item of order.items) {
        const gross = item.unit_price_cents * item.qty;
        bySeller.set(item.seller_id, (bySeller.get(item.seller_id) || 0) + gross);
      }

      for (const [sellerId, grossCents] of bySeller) {
        const commissionCents = Math.round((grossCents * order.commission_bps) / 10000);
        const netCents = grossCents - commissionCents;
        const sellerAccount = getOrCreateWalletAccount(sellerId, order.currency);

        if (commissionCents > 0) {
          postTransfer({
            fromAccountId: escrowAccount.id, toAccountId: feeAccount.id,
            amountCents: commissionCents, currency: order.currency,
            type: 'fee', memo: `Platform commission — order ${order.id}`,
            idempotencyKey: `escrow-fee-${order.id}-${sellerId}`,
          });
        }
        postTransfer({
          fromAccountId: escrowAccount.id, toAccountId: sellerAccount.id,
          amountCents: netCents, currency: order.currency,
          type: 'payout', memo: `Escrow release — order ${order.id}`,
          idempotencyKey: `escrow-payout-${order.id}-${sellerId}`,
        });
      }

      db.prepare(`
        UPDATE orders SET status = 'delivered', escrow_status = 'released', updated_at = datetime('now')
        WHERE id = ?
      `).run(order.id);
    });

    release();
    audit.log(req.user.sub, 'escrow_released', { targetType: 'order', targetId: order.id });

    const sellerIds = [...new Set(order.items.map((i) => i.seller_id))];
    for (const sellerId of sellerIds) {
      await notifications.notify(sellerId, {
        type: 'payout', title: 'Funds Released', body: `Escrow for order ${order.id} has been released to your wallet.`,
      });
    }

    res.json({ order: { ...order, status: 'delivered', escrow_status: 'released' } });
  } catch (err) { next(err); }
});

// Cancel + refund. Only allowed before shipping — once a seller has shipped,
// disputing the order requires the (Phase 2) dispute flow rather than a
// unilateral cancel, so escrow can't be pulled out from under a shipped item.
router.post('/:id/cancel', requireAuth, async (req, res, next) => {
  try {
    const order = loadOrderWithItems(req.params.id);
    if (!order) return res.status(404).json({ error: 'not_found' });
    const isBuyer = order.buyer_id === req.user.sub;
    const isSeller = order.items.some((i) => i.seller_id === req.user.sub);
    if (!isBuyer && !isSeller) return res.status(403).json({ error: 'forbidden' });
    if (order.status !== 'processing') return res.status(409).json({ error: 'invalid_state', status: order.status });
    if (order.escrow_status !== 'held') return res.status(409).json({ error: 'escrow_already_settled' });

    const cancel = db.transaction(() => {
      const escrowAccount = getOrCreateSystemAccount('escrow', order.currency);
      const buyerAccount = getOrCreateWalletAccount(order.buyer_id, order.currency);

      postTransfer({
        fromAccountId: escrowAccount.id, toAccountId: buyerAccount.id,
        amountCents: order.total_cents, currency: order.currency,
        type: 'refund', memo: `Order ${order.id} cancelled — full refund`,
        idempotencyKey: `escrow-refund-${order.id}`,
      });

      for (const item of order.items) {
        db.prepare(`UPDATE products SET stock = stock + ? WHERE id = ?`).run(item.qty, item.product_id);
      }

      db.prepare(`
        UPDATE orders SET status = 'cancelled', escrow_status = 'refunded', updated_at = datetime('now')
        WHERE id = ?
      `).run(order.id);
    });

    cancel();
    audit.log(req.user.sub, 'order_cancelled', { targetType: 'order', targetId: order.id });

    await notifications.notify(order.buyer_id, {
      type: 'refund', title: 'Order Cancelled', body: `Order ${order.id} was cancelled and refunded.`,
    });

    res.json({ order: { ...order, status: 'cancelled', escrow_status: 'refunded' } });
  } catch (err) { next(err); }
});

// Buyer reviews a delivered item. One review per order item, and only the
// buyer who actually received it — prevents fake/seller-authored reviews.
router.post('/:id/items/:itemId/review', requireAuth, (req, res, next) => {
  try {
    const order = db.prepare(`SELECT * FROM orders WHERE id = ?`).get(req.params.id);
    if (!order) return res.status(404).json({ error: 'not_found' });
    if (order.buyer_id !== req.user.sub) return res.status(403).json({ error: 'forbidden' });
    if (order.status !== 'delivered') return res.status(409).json({ error: 'order_not_delivered' });

    const item = db.prepare(`SELECT * FROM order_items WHERE id = ? AND order_id = ?`).get(req.params.itemId, order.id);
    if (!item) return res.status(404).json({ error: 'not_found' });

    const existing = db.prepare(`SELECT id FROM reviews WHERE order_item_id = ?`).get(item.id);
    if (existing) return res.status(409).json({ error: 'already_reviewed' });

    const body = reviewSchema.parse(req.body);
    const id = uuid();
    db.prepare(`
      INSERT INTO reviews (id, order_item_id, reviewer_id, product_id, seller_id, rating, comment)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, item.id, req.user.sub, item.product_id, item.seller_id, body.rating, body.comment || null);

    res.status(201).json({ review: db.prepare('SELECT * FROM reviews WHERE id = ?').get(id) });
  } catch (err) { next(err); }
});

module.exports = router;
