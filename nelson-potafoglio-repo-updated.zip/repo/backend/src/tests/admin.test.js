const request = require('supertest');
const { migrate, db } = require('../config/db');
migrate();
const createApp = require('../app');

const app = createApp();

async function registerAndLogin(emailPrefix) {
  const email = `${emailPrefix}-${Date.now()}-${Math.random()}@example.com`;
  const password = 'Str0ngPassw0rd!';
  const reg = await request(app).post('/auth/register').send({ name: emailPrefix, email, password });
  return { userId: reg.body.user.id, accessToken: reg.body.accessToken, email };
}

describe('admin routes', () => {
  test('a regular user cannot access admin routes', async () => {
    const user = await registerAndLogin('plainuser');
    const res = await request(app).get('/admin/users').set('Authorization', `Bearer ${user.accessToken}`);
    expect(res.status).toBe(403);
    expect(res.body.error).toBe('admin_required');
  });

  test('an admin can list users, review KYC, and read the ledger summary', async () => {
    const admin = await registerAndLogin('adminuser');
    db.prepare(`UPDATE users SET role = 'admin' WHERE id = ?`).run(admin.userId);
    // Role is embedded in the JWT at login time, so re-authenticate after the promotion.
    const relogged = await request(app).post('/auth/login').send({ email: admin.email, password: 'Str0ngPassw0rd!' });
    const adminToken = relogged.body.accessToken;

    const target = await registerAndLogin('kycuser');
    db.prepare(`UPDATE users SET kyc_status = 'pending' WHERE id = ?`).run(target.userId);

    const pending = await request(app).get('/admin/kyc/pending').set('Authorization', `Bearer ${adminToken}`);
    expect(pending.status).toBe(200);
    expect(pending.body.users.some((u) => u.id === target.userId)).toBe(true);

    const decide = await request(app).patch(`/admin/kyc/${target.userId}`)
      .set('Authorization', `Bearer ${adminToken}`).send({ decision: 'verified' });
    expect(decide.status).toBe(200);
    expect(decide.body.kycStatus).toBe('verified');

    const summary = await request(app).get('/admin/ledger/summary').set('Authorization', `Bearer ${adminToken}`);
    expect(summary.status).toBe(200);
    expect(Array.isArray(summary.body.byCurrency)).toBe(true);
  });

  test('suspending a user blocks their next authenticated request immediately', async () => {
    const admin = await registerAndLogin('adminuser2');
    db.prepare(`UPDATE users SET role = 'admin' WHERE id = ?`).run(admin.userId);
    const relogged = await request(app).post('/auth/login').send({ email: admin.email, password: 'Str0ngPassw0rd!' });
    const adminToken = relogged.body.accessToken;

    const target = await registerAndLogin('suspenduser');
    const suspend = await request(app).patch(`/admin/users/${target.userId}`)
      .set('Authorization', `Bearer ${adminToken}`).send({ suspended: true });
    expect(suspend.status).toBe(200);

    // The target's still-valid access token is rejected immediately — no need to wait for expiry.
    const blocked = await request(app).get('/auth/me').set('Authorization', `Bearer ${target.accessToken}`);
    expect(blocked.status).toBe(403);
    expect(blocked.body.error).toBe('account_suspended');
  });
});
