const { verifyAccessToken } = require('../services/auth');

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing_token' });

  try {
    req.user = verifyAccessToken(token); // { sub, email, role }
  } catch (err) {
    return res.status(401).json({ error: 'invalid_or_expired_token' });
  }

  // Re-check suspension on every request (not just at login) so suspending an
  // account takes effect immediately instead of waiting for token expiry.
  const { db } = require('../config/db');
  const row = db.prepare('SELECT suspended FROM users WHERE id = ?').get(req.user.sub);
  if (!row) return res.status(401).json({ error: 'invalid_or_expired_token' });
  if (row.suspended) return res.status(403).json({ error: 'account_suspended' });

  next();
}

/** KYC-gated routes: money movement should require a verified user. */
function requireKyc(req, res, next) {
  const { db } = require('../config/db');
  const user = db.prepare('SELECT kyc_status FROM users WHERE id = ?').get(req.user.sub);
  if (!user || user.kyc_status !== 'verified') {
    return res.status(403).json({ error: 'kyc_required', kyc_status: user ? user.kyc_status : 'unverified' });
  }
  next();
}

/** Admin-only routes. Role check only — real deployments should add
 * per-permission roles (Support/Finance/KYC Reviewer) once there's more
 * than one admin; this is the minimum viable gate for launch. */
function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'admin_required' });
  next();
}

module.exports = { requireAuth, requireKyc, requireAdmin };
