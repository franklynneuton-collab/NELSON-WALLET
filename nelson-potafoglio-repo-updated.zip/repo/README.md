# NELSON × Potafoglio

AI-powered e-commerce marketplace + digital wallet app.

## Structure
- `/frontend` — single-file React (CDN/Babel) prototype UI (`index.html`)
- `/backend` — Node.js/Express API: double-entry ledger, Argon2id auth, KYC (Smile Identity), Paystack, Firebase FCM

See `/backend/README.md` for backend setup (env vars, running, tests).

## Status
Frontend and backend are **not yet wired together** (frontend is still a standalone prototype; backend exposes its own REST routes under `/src/routes`). Backend uses stub provider interfaces for KYC/Paystack/FCM pending real credentials.

### Backend — recently completed
- Escrow: `POST /orders` now holds funds in an `escrow` ledger account instead of paying sellers directly. `POST /orders/:id/ship` (seller-only) and `POST /orders/:id/confirm` (buyer-only) drive the state machine; `confirm` is the only action that releases escrow, splitting each seller's share into a net payout and a platform commission (`PLATFORM_COMMISSION_BPS` env var, default 10%).
- `POST /orders/:id/cancel` — full refund + stock restoration, only while an order is still `processing` (pre-shipment).
- Order status is now authorized: only the buyer, an order's sellers, or an admin can act on it — the old open `PATCH /orders/:id/status` (anyone could set any order to any status) is removed.
- Reviews: `POST /orders/:id/items/:itemId/review` — one review per delivered order item, buyer-only. `GET /products/:id/reviews` for the aggregate.
- Admin dashboard API under `/admin` (role-gated): users, KYC queue + approve/reject, suspend/promote a user, orders, products, ledger/commission summary, audit log. Suspending a user takes effect on their very next request, not just at next login.
- Audit log (`audit_logs` table) for escrow release, cancellation, KYC decisions, suspensions, role changes.
- Test suite: 21 passing (`cd backend && npm test`), including the full ship→confirm escrow lifecycle, double-release protection, cancel/refund, and admin authorization.

### Still open (see full engineering checklist for detail)
Frontend↔backend wiring, cart persistence, product image storage/upload, real Paystack/Smile Identity/Firebase integrations (credentials required), FX provider, email, shipping/tracking, coupons, dispute system, CI/CD, hosting/domain/legal — tracked as the next chunks of work.
