# NELSON × Potafoglio

AI-powered e-commerce marketplace + digital wallet app.

## Structure
- `/frontend` — single-file React (CDN/Babel) prototype UI (`index.html`)
- `/backend` — Node.js/Express API: double-entry ledger, Argon2id auth, KYC (Smile Identity), Paystack, Firebase FCM

See `/backend/README.md` for backend setup (env vars, running, tests).

## Status
Frontend and backend are not yet wired together (frontend is a standalone prototype; backend exposes its own REST routes under `/src/routes`). Backend uses stub provider interfaces for KYC/Paystack/FCM pending real credentials.
